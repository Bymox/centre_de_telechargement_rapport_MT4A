# =============================================================================
# utils/calculator.py
# =============================================================================
# Script pour calculer le gain total, NF total et IP1dB d'entrée d'une chaîne RF.
# Il lit :
#   - components.yaml : caractéristiques des composants (LNA, filtres, attenuateurs...)
#   - chain.yaml      : ordre d'utilisation des composants dans la chaîne
#   - config.yaml     : configuration (fréquence de calcul, filtres variables, etc.)
# =============================================================================

import os
import sys
import yaml
import math
import numpy as np

# -------------------------------------------------------------------------
# Ajouter le répertoire parent au sys.path pour pouvoir importer les composants
# -------------------------------------------------------------------------
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Import des composants
from components.switch import Switch
from components.lna import LNA
from components.attenuator_fixed import AttenuatorFixed
from components.attenuator_variable import AttenuatorVariable
from components.mixer import Mixer

# =============================================================================
# Fonctions utilitaires
# =============================================================================
def db2lin(db: float) -> float:
    """Convertit dB → linéaire"""
    return 10 ** (db / 10)

def lin2db(lin: float) -> float:
    """Convertit linéaire → dB"""
    return 10 * math.log10(lin)

def read_s21(path: str, freq_MHz: float) -> float:
    """Lit un fichier S21 et retourne l'atténuation/gain à la fréquence souhaitée"""
    data = np.loadtxt(path, comments="#", usecols=(0,1))
    freqs = data[:,0]
    if freqs.max() > 1e6:
        freqs = freqs / 1e6  # Hz → MHz si nécessaire
    s21 = data[:,1]
    idx = np.argmin(np.abs(freqs - freq_MHz))
    val = float(s21[idx])
    print(f"  [read_s21] {os.path.basename(path)} @ {freq_MHz} MHz → {val}")
    return val

def lookup_vs_freq(table: list, freq_MHz: float, key: str) -> float:
    """Retourne la valeur (gain ou atténuation) correspondant à freq_MHz dans une table vs fréquence"""
    for e in table:
        fmin, fmax = e["freq_range_MHz"]
        if fmin <= freq_MHz <= fmax:
            return e[key]
    # Si hors plage, retourne la moyenne de la table
    return float(np.mean([e[key] for e in table]))

# =============================================================================
# Construction de la chaîne RF
# =============================================================================
def build_chain(components_yaml, chain_yaml, config_yaml):
    """
    Construit la chaîne RF étape par étape :
    - Lit la configuration et les composants
    - Pour chaque composant, calcule gain_lin, nf_lin, p1db_lin
    - Pour le mixer, bascule f_apply → f_FI
    """
    print("=== build_chain ===")
    cfg = yaml.safe_load(open(config_yaml))
    f_rf    = cfg["calculator_freq_MHz"]
    f_fi    = cfg.get("freq_FI_MHz", f_rf)
    print(f"[config] calculator_freq_MHz = {f_rf}, freq_FI_MHz = {f_fi}")

    f_apply = f_rf   # fréquence en cours de traitement
    var_filters = cfg.get("variable_filters", {})
    comps       = yaml.safe_load(open(components_yaml))
    chain_def   = yaml.safe_load(open(chain_yaml))["chain"]

    chain = []
    for entry in chain_def:
        name = entry["name"]
        print(f"\n-- Composant '{name}' @ {f_apply} MHz --")

        if name not in comps:
            if name in var_filters:
                print("  → stub variable_filter")
                comps[name] = {"type": "variable_filter", "op1db_dBm": 1000}
            else:
                raise KeyError(f"{name} absent de {components_yaml}")

        c = comps[name]
        t = c["type"]
        base_op1 = c.get("op1db_dBm", 1000)

        # --- Traitement des filtres variables ---
        if t == "variable_filter":
            vf = var_filters[name]
            fname = vf["filter_name"]
            state = vf["state"]
            X = fname[3:] if fname.upper().startswith("LPF") else None
            if X is None or not X.isdigit():
                raise ValueError(f"Nom invalide variable_filter: {fname}")
            dat_path = os.path.join("data/Image_filter", f"dataLPF{X}", f"S21_state{state}.dat")
            if not os.path.isfile(dat_path):
                raise FileNotFoundError(f"{name}: fichier introuvable → {dat_path}")
            loss = read_s21(dat_path, f_apply)
            st = {"name": name, "type": "filter",
                  "gain_dB": loss, "nf_dB": abs(loss),
                  "op1db_dBm": base_op1,
                  "gain_lin": db2lin(loss),
                  "nf_lin": db2lin(abs(loss)),
                  "p1db_lin": db2lin(base_op1)}
            chain.append(st)
            print(f"  → stage ajouté: {st}")
            continue

        # --- Traitement des filtres ---
        if t == "filter":
            path = c.get("path")
            # filtre = dossier (HPF + LPF)
            if path and os.path.isdir(path):
                hpf_file = os.path.join(path, "HPF_S21.dat")
                lpf_file = os.path.join(path, "LPF_S21.dat")
                loss_hpf = read_s21(hpf_file, f_apply)
                loss_lpf = read_s21(lpf_file, f_apply)
                for suffix, loss in zip(["HPF", "LPF"], [loss_hpf, loss_lpf]):
                    stg = {"name": f"{name}_{suffix}", "type": "filter",
                           "gain_dB": loss, "nf_dB": abs(loss),
                           "op1db_dBm": base_op1,
                           "gain_lin": db2lin(loss),
                           "nf_lin": db2lin(abs(loss)),
                           "p1db_lin": db2lin(base_op1)}
                    chain.append(stg)
                    print(f"  → stage ajouté: {stg}")
            # filtre = fichier unique
            elif path and os.path.isfile(path):
                loss = read_s21(path, f_apply)
                st = {"name": name, "type": "filter",
                      "gain_dB": loss, "nf_dB": abs(loss),
                      "op1db_dBm": base_op1,
                      "gain_lin": db2lin(loss),
                      "nf_lin": db2lin(abs(loss)),
                      "p1db_lin": db2lin(base_op1)}
                chain.append(st)
                print(f"  → stage ajouté: {st}")
            # stub
            else:
                loss = c.get("insertion_loss_dB", 0.0)
                st = {"name": name, "type": "filter",
                      "gain_dB": loss, "nf_dB": abs(loss),
                      "op1db_dBm": base_op1,
                      "gain_lin": db2lin(loss),
                      "nf_lin": db2lin(abs(loss)),
                      "p1db_lin": db2lin(base_op1)}
                chain.append(st)
                print(f"  → stage ajouté: {st}")
            continue

        # --- Atténuateurs ---
        if t in ("attenuator_fixed", "attenuator_variable"):
            a = c["attenuation_dB"]
            st = {"name": name, "type": t,
                  "gain_dB": -a, "nf_dB": a,
                  "op1db_dBm": base_op1,
                  "gain_lin": db2lin(-a),
                  "nf_lin": db2lin(a),
                  "p1db_lin": db2lin(base_op1)}
            chain.append(st)
            print(f"  [attenuator] attenuation @ {f_apply}MHz = {a}")
            continue

        # --- Switch ---
        if t == "switch":
            att = lookup_vs_freq(c["attenuation_vs_freq"], f_apply, "attenuation_dB")
            st = {"name": name, "type": "switch",
                  "gain_dB": -att, "nf_dB": att,
                  "op1db_dBm": base_op1,
                  "gain_lin": db2lin(-att),
                  "nf_lin": db2lin(att),
                  "p1db_lin": db2lin(base_op1)}
            chain.append(st)
            print(f"  [switch] attenuation_vs_freq @ {f_apply}MHz = {att}")
            continue

        # --- LNA ---
        if t == "lna":
            gain = lookup_vs_freq(c["gain_vs_freq"], f_apply, "gain_dB")
            st = {"name": name, "type": "lna",
                  "gain_dB": gain, "nf_dB": c["nf_dB"],
                  "op1db_dBm": base_op1,
                  "oob_att_dB": c.get("out_of_band_attenuation_dB", 60),
                  "gain_lin": db2lin(gain),
                  "nf_lin": db2lin(c["nf_dB"]),
                  "p1db_lin": db2lin(base_op1)}
            chain.append(st)
            print(f"  [lna] gain_vs_freq @ {f_apply}MHz = {gain}")
            continue

        # --- Mixer ---
        if t == "mixer":
            loss = lookup_vs_freq(c["conversion_loss_vs_freq"], f_apply, "loss_dB")
            st = {"name": name, "type": "mixer",
                  "gain_dB": -loss, "nf_dB": c.get("nf_dB", loss),
                  "op1db_dBm": base_op1,
                  "gain_lin": db2lin(-loss),
                  "nf_lin": db2lin(c.get("nf_dB", loss)),
                  "p1db_lin": db2lin(base_op1)}
            chain.append(st)
            print(f"  [mixer] conversion_loss_vs_freq @ {f_apply}MHz = {loss}")
            # bascule vers fréquence FI après le mixer
            f_apply = f_fi
            print(f"  → basculement f_apply → {f_apply} MHz (FI)")
            continue

        raise ValueError(f"type inconnu: {t}")

    print("\n=== Chaîne construite ===")
    for s in chain:
        print(f"  - {s['name']}: gain_dB={s['gain_dB']}, nf_dB={s['nf_dB']}, op1db_dBm={s['op1db_dBm']}")

    return chain

# =============================================================================
# Calcul de NF total via formule de Friis
# =============================================================================
def calc_nf(chain):
    print("\n--- calc_nf ---")
    nf = chain[0]["nf_lin"]
    g  = chain[0]["gain_lin"]
    for i, s in enumerate(chain[1:], 1):
        nf += (s["nf_lin"] - 1) / g
        g  *= s["gain_lin"]
    tot_nf = lin2db(nf)
    print(f"  NF total = {tot_nf}")
    return tot_nf

# =============================================================================
# Calcul de l'IP1dB d'entrée
# =============================================================================
def calc_ip1db(chain):
    print("\n--- calc_ip1db ---")
    N = len(chain)
    ga = [1.0]*N
    prod = 1.0
    for i in range(N-1, -1, -1):
        ga[i] = prod
        prod *= chain[i]["gain_lin"]
    inv = 0.0
    for i, s in enumerate(chain):
        inv += 1.0 / (s["p1db_lin"] * ga[i])
    p1out = lin2db(1.0 / inv)
    gtot  = lin2db(math.prod(s["gain_lin"] for s in chain))
    ip1   = p1out - gtot
    print(f"  IP1dB entrée = {ip1}")
    return ip1

# =============================================================================
# Affichage résumé
# =============================================================================
def print_summary(chain):
    print("\n=== Résumé RF ===")
    gtot  = lin2db(math.prod(s["gain_lin"] for s in chain))
    nftot = calc_nf(chain)
    ip1   = calc_ip1db(chain)
    print(f"\nGain total    : {gtot}")
    print(f"NF total      : {nftot}")
    print(f"IP1dB entrée  : {ip1}")

# =============================================================================
# Execution standalone
# =============================================================================
if __name__ == "__main__":
    base       = os.path.dirname(__file__)
    comp_yaml  = os.path.join(base, "../config/components.yaml")
    chain_yaml = os.path.join(base, "../config/chain.yaml")
    cfg_yaml   = os.path.join(base, "../config/config.yaml")

    chain = build_chain(comp_yaml, chain_yaml, cfg_yaml)
    print_summary(chain)
