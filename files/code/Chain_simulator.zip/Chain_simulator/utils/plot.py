# =============================================================================
# plot.py
# =============================================================================
# Script pour afficher un spectre RF simulé à partir d'une liste de fréquences et
# de puissances. Permet :
#   - annotation des signaux principaux
#   - affichage des markers spéciaux (RF, Image, etc.)
#   - affichage d'un résumé (gain, NF, IP1dB)
#   - export de la figure en PNG
# =============================================================================

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.cm as cm

# Affichage interactif mais non-bloquant
plt.show(block=False)

# =============================================================================
# Fonction principale
# =============================================================================
def plot_spectrum(freqs_MHz,
                  powers_dBm,
                  markers=None,                # [(freq, power, couleur, label), ...]
                  fmin=0,
                  fmax=20000,
                  ymin=-100,
                  ymax=0,
                  rf_freq_MHz=None,
                  final_rf_power_dBm=None,
                  fi_freq_MHz=None,
                  fi_power_dBm=None,
                  ytick_step=10,
                  xtick_step_GHz=0.1,
                  min_power_dBm=-200,         # seuil minimal pour annoter
                  annot_range_MHz=(0,20000),  # plage de fréquences pour annoter
                  annot_color="#F31123A4",    # couleur des annotations
                  summary_freq_GHz=None,       # fréquence pour résumé top-right
                  summary_gain_dB=None,
                  summary_nf_dB=None,
                  summary_ip1dB=None):

    # Conversion MHz → GHz pour l'affichage
    freqs_GHz = [f/1000 for f in freqs_MHz]
    fmin_GHz, fmax_GHz = fmin/1000, fmax/1000
    a_fmin, a_fmax = annot_range_MHz

    # Filtrer les signaux visibles pour le coloriage
    visible = [(f,p) for f,p in zip(freqs_MHz, powers_dBm)
               if a_fmin <= f <= a_fmax and p >= min_power_dBm]
    visible.sort(key=lambda x:x[1], reverse=True)
    cmap = cm.get_cmap('tab20', max(1,len(visible)))

    plt.figure(figsize=(13,7))
    annotations = []

    # -------------------------------
    # Tracé du spectre
    # -------------------------------
    for f,p in zip(freqs_MHz, powers_dBm):
        fG = f/1000
        if not (fmin <= f <= fmax):
            # fréquences hors plage → ligne rouge en pointillé
            plt.vlines(fG, ymin, p, color='red', linestyle='--', linewidth=1)
            continue
        if (a_fmin<=f<=a_fmax) and p>=min_power_dBm:
            # fréquences visibles dans plage d'annotation → couleur tab20
            idx = visible.index((f,p))
            col = cmap(idx)
            plt.vlines(fG, ymin, p, color=col, linewidth=2)
            plt.plot(fG,p,'o',color=col,markersize=6)
            annotations.append((fG,p,col))
        else:
            # lignes hors annotation → rouge pointillé
            plt.vlines(fG, ymin, p, color='red', linestyle='--', linewidth=1)

    # -------------------------------
    # Annoter les signaux sur la gauche
    # -------------------------------
    x0 = fmin_GHz + (fmax_GHz-fmin_GHz)*0.01
    y0 = ymax - (ymax-ymin)*0.02
    dy = (ymax-ymin)*0.04
    for i,(fG,p,col) in enumerate(annotations):
        plt.text(x0, y0-i*dy,
                 f"{fG:.3f} GHz → {p:.1f} dBm",
                 ha='left', va='top',
                 fontsize=10, fontweight='bold',
                 color=col,
                 bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.35'))

    # -------------------------------
    # Tracé des markers spéciaux
    # -------------------------------
    if markers:
        for f,p,color,label in markers:
            fG = f/1000
            c = color if color else 'gray'
            lw = 2 if color else 1
            ls = '-' if color else '--'
            plt.vlines(fG, ymin, p, color=c, linewidth=lw, linestyle=ls)
            if label and (fmin <= f <= fmax):
                plt.text(fG, p + (ymax-ymin)*0.02,
                         label, ha='center', va='bottom',
                         fontsize=8, rotation=35, fontweight='bold',
                         bbox=dict(facecolor='white',edgecolor='black',boxstyle='round,pad=0.3'))

    # -------------------------------
    # Résumé des performances top-right
    # -------------------------------
    if summary_freq_GHz is not None:
        lines = [
            f"Freq= {summary_freq_GHz:.3f} GHz",
            f"G_max= {summary_gain_dB:.2f} dB",
            f"NF=    {summary_nf_dB:.2f} dB",
            f"IIP1dB= {summary_ip1dB:.2f} dBm"
        ]
        xpos = fmax_GHz*0.998
        ypos = ymax - (ymax-ymin)*0.02
        for i,ln in enumerate(lines):
            plt.text(xpos, ypos - i*(ymax-ymin)*0.037, ln,
                     ha='right', va='top',
                     fontsize=9, fontfamily='Calibri',
                     fontweight='bold',
                     color='black',
                     bbox=dict(facecolor='white',edgecolor='darkblue',boxstyle='round,pad=0.3'))

    # -------------------------------
    # Finalisation du plot
    # -------------------------------
    plt.xlim(fmin_GHz, fmax_GHz)
    plt.ylim(ymin, ymax)
    plt.xlabel("Fréquence (GHz)")
    plt.ylabel("Puissance (dBm)")
    plt.title("Spectre simulé")
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.xticks(np.arange(fmin_GHz, fmax_GHz+1e-6, xtick_step_GHz))
    plt.yticks(np.arange(ymin, ymax+1, ytick_step))
    plt.tight_layout()
    plt.savefig("Spectrum.png")  # export automatique
