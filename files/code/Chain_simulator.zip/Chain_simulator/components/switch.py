# components/switch.py

from components.base import Component

class Switch(Component):
    """
    Composant Switch RF simulé.
    - Applique une atténuation dépendante de la fréquence.
    - Les plages d'atténuation sont définies dans le YAML via 'attenuation_vs_freq'.
    """

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique l'atténuation à chaque fréquence.
        :param signals: {freq_MHz: puissance_dBm} en entrée
        :return: {freq_MHz: puissance_dBm} après atténuation
        """
        out = {}
        for f, p in signals.items():
            att_dB = 0.0  # valeur par défaut si fréquence hors plage

            # recherche la plage correspondante
            for entry in self.params["attenuation_vs_freq"]:
                fmin, fmax = entry["freq_range_MHz"]
                if fmin <= f <= fmax:
                    att_dB = entry["attenuation_dB"]
                    break  # on prend la première plage correspondante

            # puissance de sortie = puissance entrée - atténuation
            out[f] = p - att_dB

        return out
