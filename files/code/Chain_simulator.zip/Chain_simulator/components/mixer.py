import numpy as np
from components.base import Component

class Mixer(Component):
    """
    Composant Mixer superhétérodyne simulé.
    - Calcule la FI pour chaque signal RF.
    - Applique perte de conversion.
    - Ajoute fuite RF et LO si définie.
    - Génère des spurious m*f_RF ± n*LO selon table.
    """

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        :param signals: dictionnaire {freq_MHz: puissance_dBm} RF en entrée
        :return: dictionnaire {freq_MHz: puissance_dBm} incluant FI et spurious
        """
        out = {}

        ol_freq = self.params["lo_freq_MHz"]                   # fréquence LO
        mode = self.params.get("mode", "high")                # 'high' = supradyne / 'low' = infradyne
        ref_rf_dBm = self.params.get("ref_rf_dBm", -10)       # référence pour spurious
        spurs_table = self.params["puissance_spurious"]       # tableau 5x6
        conv_loss_table = self.params["conversion_loss_vs_freq"]

        rf_leak_dBc = self.params.get("rf_to_fi_leakage_dBc", None)
        lo_leak_dBc = self.params.get("lo_to_fi_leakage_dBc", None)
        p_lo = self.params.get("lo_power_dBm", None)

        # Log de départ
        print(f"=== Mixer process start ===")
        print(f"LO freq = {ol_freq} MHz, mode = {mode}")
        print(f"Input signals:")
        for f_rf, p_rf in signals.items():
            print(f"  RF freq: {f_rf} MHz, power: {p_rf} dBm")

        for f_rf, p_rf in signals.items():
            # 1) Calcul FI (|LO - RF|)
            f_fi = abs(f_rf - ol_freq)
            print(f"\nCalcul FI: |LO - RF| = |{ol_freq} - {f_rf}| = {f_fi} MHz")

            # 2) Lookup de la perte de conversion selon FI
            loss_dB = 0
            for entry in conv_loss_table:
                fmin, fmax = entry["freq_range_MHz"]
                if fmin <= f_fi <= fmax:
                    loss_dB = entry["loss_dB"]
                    print(f"  Conversion loss for FI={f_fi} MHz found: {loss_dB} dB")
                    break
            if loss_dB == 0:
                print(f"  No conversion loss found for FI={f_fi} MHz, loss=0 dB")

            # puissance FI après conversion
            p_fi = p_rf - loss_dB
            print(f"  FI power = RF power ({p_rf} dBm) - loss ({loss_dB} dB) = {p_fi} dBm")
            out[f_fi] = self.add_power(out.get(f_fi), p_fi)

            self.last_fi_freq = f_fi
            self.last_fi_power = p_fi

            # 3) Fuite RF→FI
            if rf_leak_dBc is not None:
                leak_power = p_rf + rf_leak_dBc
                print(f"  Leakage RF->FI: {p_rf:.2f} + {rf_leak_dBc} = {leak_power:.2f} dBm ajouté à la FI {f_fi} MHz")
                out[f_fi] = self.add_power(out.get(f_fi), leak_power)

            # 4) Fuite LO→FI (à f_LO)
            if lo_leak_dBc is not None and p_lo is not None:
                leak_power = p_lo + lo_leak_dBc
                print(f"  Leakage LO->FI: {p_lo} + {lo_leak_dBc} = {leak_power} dBm added to LO freq {ol_freq} MHz")
                out[ol_freq] = self.add_power(out.get(ol_freq), leak_power)

            # 5) Génération de spurious m*f_RF ± n*LO
            print(f"  Calcul des spurious:")
            for m in range(1, 6):      # m ∈ [1,5]
                for n in range(0, 6):  # n ∈ [0,5]
                    spur_dBc = spurs_table[m - 1][n]
                    if spur_dBc == "ref":
                        continue

                    # Correction pour m≠1 ou n≠0
                    if m == 1 and n == 0:
                        dBc_adj = spur_dBc
                    else:
                        dBc_adj = spur_dBc + m * (p_rf - ref_rf_dBm)

                    spur_power_dBm = p_rf + dBc_adj

                    # fréquences des spurious
                    spur_freq_pos = abs(m * f_rf + n * ol_freq)
                    spur_freq_neg = abs(m * f_rf - n * ol_freq)

                    print(f"    m={m}, n={n}, spur_dBc={spur_dBc}, dBc_adj={dBc_adj:.2f}, "
                          f"freq+={spur_freq_pos} MHz, freq-={spur_freq_neg} MHz, "
                          f"power={spur_power_dBm:.2f} dBm")

                    # sommation si plusieurs contributions vers la même fréquence
                    out[spur_freq_pos] = self.add_power(out.get(spur_freq_pos), spur_power_dBm)
                    if spur_freq_pos != spur_freq_neg:
                        out[spur_freq_neg] = self.add_power(out.get(spur_freq_neg), spur_power_dBm)

        print(f"=== Mixer process end ===\n")
        return out

    @staticmethod
    def add_power(existing_dBm, new_dBm):
        """
        Additionne des puissances en dBm (linéairement)
        :param existing_dBm: puissance existante sur la fréquence
        :param new_dBm: puissance à ajouter
        :return: puissance totale en dBm
        """
        if existing_dBm is None:
            return new_dBm
        lin = 10 ** (existing_dBm / 10) + 10 ** (new_dBm / 10)
        return 10 * np.log10(lin)
