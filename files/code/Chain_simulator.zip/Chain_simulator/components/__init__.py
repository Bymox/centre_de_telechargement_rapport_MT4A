# components/__init__.py

# Importation des classes concretes de composants depuis le dossier components/
from components.lna import LNA
from components.switch import Switch
from components.preselector import Preselector
from components.attenuator_fixed import AttenuatorFixed
from components.attenuator_variable import AttenuatorVariable
from components.variable_filter import VariableFilter
from components.mixer import Mixer
from components.bpf_500_filter import BPF500Filter
from components.HPF_4GHz import HPF_4GHz
from components.filter import Filter     # ← notre nouvelle classe "Filter"

# Dictionnaire qui mappe un nom de type (string) vers la classe correspondante
# Cela permet de créer dynamiquement des composants à partir d'un YAML
component_classes = {
    "lna": LNA,
    "switch": Switch,
    "preselector": Preselector,
    "attenuator_fixed": AttenuatorFixed,
    "attenuator_variable": AttenuatorVariable,
    "variable_filter": VariableFilter,
    "mixer": Mixer,
    "HPF4G": HPF_4GHz,
    "bpf_500_filter": BPF500Filter,
    "filter": Filter,    # ← mappe "filter" ici pour la création dynamique
}

# Fonction utilitaire pour créer un composant à partir de son nom et de sa config
def create_component(name, config):
    """
    :param name: Nom unique du composant (ex. "LNA1")
    :param config: dictionnaire venant du YAML avec au minimum la clé "type"
    :return: instance de la classe correspondante
    """
    ctype = config["type"]  # On récupere le type de composant
    if ctype not in component_classes:  # Vérification que le type existe
        raise ValueError(f"Unknown component type: {ctype}")  # Erreur si inconnu
    # Création de l'instance en passant le nom et le config
    return component_classes[ctype](name, config)
