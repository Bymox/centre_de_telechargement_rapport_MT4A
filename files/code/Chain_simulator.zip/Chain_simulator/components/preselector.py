# components/preselector.py

import os
import numpy as np
from components.base import Component
from typing import Dict

class Preselector(Component):
    """
    Composant Preselector simulé.
    - Applique un filtre passe-haut (HPF) + passe-bas (LPF) à chaque signal.
    - Les fichiers HPF_S21.dat et LPF_S21.dat sont dans le dossier 'path' du YAML.
    - Tolérance en MHz pour trouver les points S21 les plus proches.
    """

    def __init__(self, name: str, params: dict):
        super().__init__(name, params)

        base_path = params.get("path")
        if not base_path:
            raise ValueError(f"Preselector {name} must have a 'path' defined.")

        self.hpf_path = os.path.join(base_path, "HPF_S21.dat")
        self.lpf_path = os.path.join(base_path, "LPF_S21.dat")

        if not os.path.isfile(self.hpf_path):
            raise FileNotFoundError(f"HPF_S21.dat not found at {self.hpf_path}")
        if not os.path.isfile(self.lpf_path):
            raise FileNotFoundError(f"LPF_S21.dat not found at {self.lpf_path}")

        # tolérance ±30 MHz par défaut pour trouver les points les plus proches
        self.tolerance_MHz = params.get("tolerance_MHz", 30)

    def _get_loss(self, path: str, freq_MHz: float) -> float:
        """
        Retourne la perte moyenne (dB) autour de freq_MHz ± tolerance_MHz.
        - path: chemin vers le fichier S21
        - freq_MHz: fréquence cible
        Lève ValueError si aucune mesure n'est disponible dans la plage.
        """
        data = np.loadtxt(path)  # colonne 0 : Hz, colonne 1 : dB
        freqs = data[:, 0] / 1e6  # conversion Hz → MHz
        losses = data[:, 1]

        # on sélectionne les points dans la tolérance
        mask = np.abs(freqs - freq_MHz) <= self.tolerance_MHz
        if not np.any(mask):
            raise ValueError(f"No S21 data around {freq_MHz:.1f} MHz ±{self.tolerance_MHz} MHz in {os.path.basename(path)}")

        # retourne la moyenne locale
        return float(np.mean(losses[mask]))

    def process(self, signals: Dict[float, float]) -> Dict[float, float]:
        """
        Applique la perte HPF + LPF à chaque fréquence du signal.
        - Si aucune donnée S21 n’est trouvée pour la fréquence, on laisse le signal inchangé.
        """
        output: Dict[float, float] = {}
        for freq, power in signals.items():
            try:
                hpf_loss = self._get_loss(self.hpf_path, freq)
                lpf_loss = self._get_loss(self.lpf_path, freq)
                total_loss = hpf_loss + lpf_loss
                # Les pertes S21 sont négatives → on ajoute directement
                output[freq] = power + total_loss
            except ValueError:
                # Pas de donnée S21 dans la tolérance → conserver la puissance originale
                output[freq] = power

        return output
