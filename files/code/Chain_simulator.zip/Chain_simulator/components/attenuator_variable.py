from components.base import Component  # On herite de la classe de base

class AttenuatorVariable(Component):
    """
    Composant representant un attenuateur variable.
    Permet de definir une attenuation par defaut via params, 
    mais peut aussi etre override a l'instanciation.
    """
    
    def __init__(self, name, params, attenuation_dB=None):
        """
        Constructeur
        :param name: nom du composant
        :param params: dictionnaire de parametres depuis YAML
        :param attenuation_dB: valeur optionnelle pour override l'attenuation
        """
        super().__init__(name, params)  # Appelle le constructeur de la classe de base
        # Si un override est fourni, on l'utilise ; sinon on prend la valeur du YAML, ou 0 dB par defaut
        self.attenuation_dB = attenuation_dB if attenuation_dB is not None else params.get("attenuation_dB", 0)

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique l'attenuation a tous les signaux.
        
        :param signals: dictionnaire {frequence_MHz: puissance_dBm} en entree
        :return: dictionnaire {frequence_MHz: puissance_dBm} en sortie
        """
        out = {}  # dictionnaire de sortie
        for f, p in signals.items():
            # On soustrait la valeur d'attenuation variable
            out[f] = p - self.attenuation_dB
        return out
