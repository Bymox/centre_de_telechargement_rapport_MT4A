# components/ol_filter.py

import numpy as np
from components.base import Component

class OLFilter(Component):
    """
    Filtre passe-bas appliqué sur la fréquence LO avant le mixer.
    - Charge un fichier S21 (colonne fréquence / S21).
    - Applique S21 aux signaux RF.
    - Moyenne ±tol_MHz pour lisser le signal.
    """

    def __init__(self, name: str, params: dict):
        """
        Constructeur
        :param name: nom du composant
        :param params: dictionnaire avec 'path' vers fichier S21
        """
        super().__init__(name, params)
        path = params.get("path")
        if not isinstance(path, str):
            raise ValueError(f"OLFilter '{name}' requiert un paramètre 'path' de type str.")
        self.path = path

        # Chargement des données S21 (MHz, dB)
        data = np.loadtxt(self.path, comments="#", usecols=(0,1))
        if data.ndim != 2 or data.shape[1] != 2:
            raise ValueError(f"OLFilter '{name}': format de fichier invalide, attendu 2 colonnes.")

        self.freqs_MHz = data[:, 0]  # fréquences
        self.s21_dB    = data[:, 1]  # S21 en dB

        # tolérance ±20 MHz pour moyenne autour de la fréquence
        self.tol_MHz = 20  

        print(f"OLFilter '{name}' chargé : {len(self.freqs_MHz)} points, "
              f"plage {self.freqs_MHz.min():.1f}–{self.freqs_MHz.max():.1f} MHz")

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique le filtre OL à chaque signal.
        - Moyenne ±tol_MHz si points proches.
        - Sinon interpolation linéaire.
        """
        out = {}
        f_min, f_max = self.freqs_MHz.min(), self.freqs_MHz.max()

        print(f"\n--- OLFilter (±{self.tol_MHz} MHz) ---")
        for freq, power in signals.items():
            # fréquence hors plage → conserve le signal
            if freq < f_min or freq > f_max:
                print(f"  {freq:.1f} MHz hors plage → {power:.2f} dBm")
                out[freq] = power
                continue

            # recherche des points dans ±tol_MHz
            diffs = np.abs(self.freqs_MHz - freq)
            idxs = np.where(diffs <= self.tol_MHz)[0]

            if idxs.size > 0:
                # moyenne locale
                gain_dB = float(np.mean(self.s21_dB[idxs]))
                print(f"  {freq:.1f} MHz → voisinage ±{self.tol_MHz} MHz, "
                      f"S21 moyenne = {gain_dB:.2f} dB")
            else:
                # interpolation linéaire si pas de points proches
                gain_dB = float(np.interp(freq, self.freqs_MHz, self.s21_dB))
                print(f"  {freq:.1f} MHz → interpolation, S21 = {gain_dB:.2f} dB")

            # puissance de sortie
            p_out = power + gain_dB
            print(f"    in={power:.2f} dBm, out={p_out:.2f} dBm")
            out[freq] = p_out

        print(f"--- fin OLFilter ---\n")
        return out
