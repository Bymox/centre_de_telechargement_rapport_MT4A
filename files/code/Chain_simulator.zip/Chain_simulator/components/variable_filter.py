# components/variable_filter.py

import os
import numpy as np
from components.base import Component
from typing import Dict, Tuple

class VariableFilter(Component):
    """
    Filtre RF variable.
    - Peut être un LPF ou HPF selon filter_name.
    - Chaque "state" correspond à un fichier S21 spécifique.
    - Applique une atténuation positive (gain converti en perte).
    """

    def __init__(self, name: str, params: dict):
        super().__init__(name, params)
        # Nom du filtre, ex "LPF3"
        self.filter_name = params.get("filter_name", "LPF1")
        # Etat sélectionné, ex 0,1,2...
        self.state       = params.get("state", 0)
        # tolérance utilisée uniquement pour debug
        self.tolerance_MHz = params.get("tolerance_MHz", 30)

        # Construction du chemin vers le fichier S21
        base_path = params.get("path", "Image_filter")  # défaut "Image_filter"
        base_dir  = os.path.join(base_path, f"data{self.filter_name}")
        filename  = f"S21_state{self.state}.dat"
        filepath  = os.path.join(base_dir, filename)

        # Chargement des fréquences (MHz) et atténuations (dB positives)
        self.freqs_MHz, self.atten_dB = self._load_s21(filepath)

    def _load_s21(self, filepath: str) -> Tuple[np.ndarray, np.ndarray]:
        """
        Lit un fichier S21 et renvoie (freqs_MHz, atten_dB)
        - Convertit Hz → MHz
        - Convertit S21 (dB gain) → atténuation positive
        """
        freqs = []
        atten = []
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                hz    = float(parts[0])
                s21   = float(parts[1])
                freqs.append(hz / 1e6)    # Hz → MHz
                atten.append(-s21)         # gain → atténuation positive

        if not freqs:
            raise ValueError(f"Aucune donnée dans {filepath}")

        return np.array(freqs), np.array(atten)

    def process(self, signals: Dict[float, float]) -> Dict[float, float]:
        """
        Applique le filtre variable :
        - Pour chaque fréquence du signal, cherche le point S21 le plus proche.
        - Applique son atténuation.
        - Si plusieurs signaux sur la même fréquence, cumule en linéaire.
        """
        out: Dict[float, float] = {}

        for f, p in signals.items():
            # indice du point le plus proche
            idx_min = int(np.argmin(np.abs(self.freqs_MHz - f)))
            att = self.atten_dB[idx_min]

            # puissance de sortie = puissance entrée - atténuation
            p_out = p - att

            # cumul en linéaire si même fréquence multiple
            if f in out:
                lin = 10**(out[f] / 10) + 10**(p_out / 10)
                out[f] = 10 * np.log10(lin)
            else:
                out[f] = p_out

        return out
