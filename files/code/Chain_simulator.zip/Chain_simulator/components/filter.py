# components/filter.py

import os
import numpy as np
from components.base import Component

class Filter(Component):
    """
    Composant générique pour un filtre basé sur des fichiers S21.
    Peut être un fichier unique ou un dossier contenant HPF et LPF (ex. préselector).
    """

    def __init__(self, name: str, params: dict):
        """
        Constructeur
        :param name: nom du filtre
        :param params: dictionnaire avec au minimum "path" (fichier S21 ou dossier)
        """
        super().__init__(name, params)
        path = params.get("path")
        if not isinstance(path, str):
            raise ValueError(f"Filter '{name}' requiert un paramètre 'path' de type str.")
        self.path = path
        print(f"Filter '{name}' initialisé : path = {self.path!r}")

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique le filtre à chaque signal.
        - Si path = dossier → cherche HPF_S21.dat + LPF_S21.dat et cumule.
        - Sinon → fichier unique S21.
        """
        out = {}
        for freq, power in signals.items():
            # cas d'une "bank" préselector (dossier)
            if os.path.isdir(self.path):
                hpf = os.path.join(self.path, "HPF_S21.dat")
                lpf = os.path.join(self.path, "LPF_S21.dat")
                s21_hpf = self._read_s21_at_freq(hpf, freq)
                s21_lpf = self._read_s21_at_freq(lpf, freq)
                total_s21 = s21_hpf + s21_lpf  # somme des gains/atténuations
                p_out = power + total_s21
                # log détaillé
                print(f"Filter '{self.name}': {freq:.1f}MHz → HPF={s21_hpf:.1f}dB, LPF={s21_lpf:.1f}dB → out={p_out:.2f}dBm")
            else:
                # cas d'un simple fichier S21
                s21 = self._read_s21_at_freq(self.path, freq)
                p_out = power + s21
                print(f"Filter '{self.name}': {freq:.1f}MHz → S21={s21:.1f}dB → out={p_out:.2f}dBm")
            out[freq] = p_out
        return out

    @staticmethod
    def _read_s21_at_freq(path: str, freq_MHz: float) -> float:
        """
        Lit un fichier S21 et renvoie la valeur S21 pour la fréquence demandée.
        - Interpolation non implémentée : prend le point le plus proche.
        - Conversion Hz → MHz si nécessaire.
        """
        data = np.loadtxt(path, comments="#", usecols=(0,1))
        freqs = data[:,0]
        s21   = data[:,1]
        if freqs.max() > 1e6:  # si les fréquences sont en Hz
            freqs = freqs / 1e6
        # recherche de l'indice du point le plus proche
        idx = np.argmin(np.abs(freqs - freq_MHz))
        return float(s21[idx])
