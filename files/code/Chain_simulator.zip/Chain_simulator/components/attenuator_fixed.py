from components.base import Component  # On herite de la classe de base

class AttenuatorFixed(Component):
    """
    Composant representant un attenuateur fixe.
    Il diminue la puissance de tous les signaux d'une valeur fixe en dB.
    """

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique l'attenuation fixe a chaque frequence.
        
        :param signals: dictionnaire {frequence_MHz: puissance_dBm} en entree
        :return: dictionnaire {frequence_MHz: puissance_dBm} en sortie
        """
        # On recupere l'attenuation depuis les params. Si absent, 0 dB (pas d'attenuation)
        att_dB = self.params.get("attenuation_dB", 0)
        
        out = {}  # dictionnaire de sortie
        for f, p in signals.items():
            # On applique simplement l'attenuation : puissance diminuee
            out[f] = p - att_dB
        return out
