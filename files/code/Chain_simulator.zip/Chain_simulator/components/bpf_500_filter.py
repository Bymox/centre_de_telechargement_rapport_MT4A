import numpy as np
import os
from components.base import Component
from typing import Dict

class BPF500Filter(Component):
    """
    Filtre passe-bande centré sur 500 MHz (ou valeur nominale).
    Implémente un HPF et un LPF en cascade pour créer le passe-bande.
    Utilise des fichiers S21 pour définir l'atténuation / gain.
    """

    def __init__(self, name: str, params: dict):
        """
        Constructeur
        :param name: nom du composant
        :param params: dictionnaire avec au minimum "path" vers les fichiers S21
        """
        super().__init__(name, params)

        # Récupere le chemin vers le dossier contenant S21_HPF.dat et S21_LPF.dat
        base_path = params.get("path")
        if not isinstance(base_path, str):
            raise ValueError(f"BPF500Filter '{name}' requiert un parametre 'path' de type str.")

        # Fichiers HPF et LPF
        self.hpf_file = os.path.join(base_path, "S21_HPF.dat")
        self.lpf_file = os.path.join(base_path, "S21_LPF.dat")

        # Vérifie que les fichiers existent
        for f in (self.hpf_file, self.lpf_file):
            if not os.path.isfile(f):
                raise FileNotFoundError(f"BPF500Filter: fichier introuvable : {f}")

        # Tolérance ±30 MHz pour chercher un point proche plutôt que d'interpoler
        self.tol_MHz = 30

        # Charge les fichiers S21 : colonnes freq_MHz, S21_dB
        self.hpf_freqs, self.hpf_s21 = np.loadtxt(self.hpf_file, usecols=(0,1), unpack=True)
        self.lpf_freqs, self.lpf_s21 = np.loadtxt(self.lpf_file, usecols=(0,1), unpack=True)

        # Log pour confirmation du chargement
        print(f"BPF500Filter '{name}' chargé : HPF {self.hpf_freqs.min():.0f}–{self.hpf_freqs.max():.0f} MHz, "
              f"LPF {self.lpf_freqs.min():.0f}–{self.lpf_freqs.max():.0f} MHz")

    def _lookup(self, freqs: np.ndarray, s21: np.ndarray, freq: float) -> float:
        """
        Cherche la valeur S21 pour une fréquence donnée.
        1. Si un point est proche ±tol_MHz, on fait la moyenne
        2. Sinon, interpolation linéaire
        3. Si hors plage, retourne 0 dB
        """
        # distances entre la fréquence cible et les fréquences du fichier
        diffs = np.abs(freqs - freq)
        # indices dans la tolérance
        idxs = np.where(diffs <= self.tol_MHz)[0]
        if idxs.size:
            # renvoie la moyenne si plusieurs points proches
            return float(np.mean(s21[idxs]))

        # interpolation si fréquence dans la plage
        if freq < freqs.min() or freq > freqs.max():
            # hors plage → perte 0 dB (on peut aussi forcer perte max si nécessaire)
            return 0.0
        return float(np.interp(freq, freqs, s21))

    def process(self, signals: Dict[float, float]) -> Dict[float, float]:
        """
        Applique le passe-bande HPF+LPF à chaque fréquence du signal.
        :param signals: dictionnaire {freq_MHz: puissance_dBm}
        :return: dictionnaire {freq_MHz: puissance_dBm} apres filtrage
        """
        out = {}
        print(f"\n--- BPF500Filter '{self.name}' processing (tol ±{self.tol_MHz} MHz) ---")
        for freq, power in signals.items():
            # Lookup HPF et LPF
            gain_hpf = self._lookup(self.hpf_freqs, self.hpf_s21, freq)
            gain_lpf = self._lookup(self.lpf_freqs, self.lpf_s21, freq)
            gain_total = gain_hpf + gain_lpf  # cumul des gains/atténuations
            p_out = power + gain_total        # applique au signal dBm
            # Log détaillé pour debug
            print(f"  {freq:.1f} MHz: in {power:.2f} dBm, HPF {gain_hpf:.2f} dB + LPF {gain_lpf:.2f} dB "
                  f"→ total {gain_total:.2f} dB → out {p_out:.2f} dBm")
            out[freq] = p_out
        print(f"--- BPF500Filter done ---\n")
        return out
