# components/hpf_4ghz.py

import numpy as np
from components.base import Component

class HPF_4GHz(Component):
    """
    Filtre passe-haut 4 GHz.
    Charge un fichier S21 (ou atténuation) et applique l'atténuation correspondante à chaque fréquence.
    """

    def __init__(self, name: str, params: dict):
        """
        Constructeur
        :param name: nom du composant
        :param params: dictionnaire avec 'path' vers le fichier de données
        """
        super().__init__(name, params)
        path = params.get("path")
        if not isinstance(path, str):
            raise ValueError(f"HPF_4GHz '{name}' requiert un paramètre 'path' de type str.")
        self.path = path

        # Chargement des données : colonne 0 = fréquence (Hz), colonne 1 = atténuation (dB)
        data = np.loadtxt(self.path, comments="#", usecols=(0, 1))
        if data.ndim != 2 or data.shape[1] != 2:
            raise ValueError(f"HPF_4GHz '{name}': format de fichier invalide, attendu 2 colonnes.")

        self.freqs_Hz = data[:, 0]  # fréquences
        self.loss_dB  = data[:, 1]  # atténuations correspondantes

        # Log pour debug
        print(f"HPF_4GHz '{name}' chargé : {len(self.freqs_Hz)} points, "
              f"plage {self.freqs_Hz.min()/1e6:.3f}–{self.freqs_Hz.max()/1e6:.3f} MHz")

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        Applique le filtre à chaque fréquence.
        - Cherche le point le plus proche dans le fichier S21.
        - Si hors plage → passe inchangé.
        """
        out = {}

        print(f"\n--- HPF_4GHz (recherche point le plus proche) ---")
        for freq_MHz, power_dBm in signals.items():
            freq_Hz = freq_MHz * 1e6  # conversion MHz → Hz

            # Si fréquence hors plage, laisser passer sans atténuation
            if freq_Hz < self.freqs_Hz.min() or freq_Hz > self.freqs_Hz.max():
                print(f"  {freq_MHz:.3f} MHz hors plage → {power_dBm:.2f} dBm (inchangé)")
                out[freq_MHz] = power_dBm
                continue

            # Cherche l'indice du point le plus proche
            idx = np.argmin(np.abs(self.freqs_Hz - freq_Hz))
            attenuation_dB = self.loss_dB[idx]

            # Applique l'atténuation (somme en dB)
            p_out = power_dBm + attenuation_dB
            print(f"  {freq_MHz:.3f} MHz → atténuation = {attenuation_dB:.2f} dB → sortie = {p_out:.2f} dBm")
            out[freq_MHz] = p_out

        print(f"--- fin HPF_4GHz ---\n")
        return out
