import numpy as np
from components.base import Component

class LNA(Component):
    """
    Low Noise Amplifier (LNA) simulé.
    - Applique un gain variable selon la fréquence.
    - Atténue fortement les signaux hors bande.
    - Génère la deuxième harmonique H2 pour chaque signal.
    """

    def process(self, signals: dict[float, float]) -> dict[float, float]:
        """
        :param signals: dictionnaire {freq_MHz: puissance_dBm} en entrée
        :return: dictionnaire {freq_MHz: puissance_dBm} en sortie avec gain + H2
        """
        out = {}
        # Atténuation hors bande si fréquence en dehors de gain_vs_freq
        oob_att = self.params.get("out_of_band_attenuation_dB", 30.0)

        # 1) Appliquer le gain aux signaux fondamentaux
        for f_in, p_in in signals.items():
            gain_dB = None
            # Parcourt les tranches de gain définies dans le YAML
            for entry in self.params["gain_vs_freq"]:
                fmin, fmax = entry["freq_range_MHz"]
                if fmin <= f_in <= fmax:
                    gain_dB = entry["gain_dB"]
                    break

            # Si hors plage → appliquer atténuation
            if gain_dB is None:
                gain_dB = -oob_att

            p_out = p_in + gain_dB  # puissance après amplification ou atténuation

            # Si la fréquence existe déjà dans out (fusion linéaire)
            prev = out.get(f_in)
            if prev is None:
                out[f_in] = p_out
            else:
                # conversion dBm → linéaire, somme, puis retour dB
                lin = 10**(prev/10) + 10**(p_out/10)
                out[f_in] = 10 * np.log10(lin)

            print(f"LNA '{self.name}': {f_in:.1f}MHz → gain={gain_dB:.1f}dB → out={out[f_in]:.2f}dBm")

        # 2) Génération de la deuxième harmonique H2
        h2_cfg = self.params.get("h2_generation")
        if h2_cfg:
            ref_in = h2_cfg["input_dBm"]    # référence d'entrée (ex. -20 dBm)
            ref_h2_abs = h2_cfg["h2_dBc"]   # niveau H2 en dBm absolu
            snapshot = list(out.items())     # snapshot des signaux fondamentaux

            for f, p_out in snapshot:
                p_in = signals.get(f)
                if p_in is None:
                    continue

                delta = p_in - ref_in
                # pente 2 dB/dB pour H2 (typique d'un LNA)
                p2 = ref_h2_abs + 2.0 * delta   # puissance H2 en dBm

                # fréquence H2
                f2 = 2 * f

                # sommation si plusieurs H2 convergent sur la même fréquence
                prev2 = out.get(f2)
                if prev2 is None:
                    out[f2] = p2
                else:
                    lin2 = 10**(prev2/10) + 10**(p2/10)
                    out[f2] = 10 * np.log10(lin2)

                print(f"LNA '{self.name}': généré H2 {f2:.1f}MHz → {p2:.2f}dBm")

        return out
