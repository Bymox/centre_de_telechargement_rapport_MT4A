# components/base.py

# On importe les classes nécessaires pour créer une classe abstraite
from abc import ABC, abstractmethod  
# Typing permet d'indiquer le type des entrées et sorties
from typing import Dict  

# Définition de la classe de base pour tous les composants RF
# ABC signifie Abstract Base Class : on ne peut pas l'instancier directement
class Component(ABC):
    def __init__(self, name: str, params: dict):
        """
        Constructeur du composant de base.
        :param name: nom du composant (ex. 'LNA1', 'SW2')
        :param params: dictionnaire contenant les parametres du composant
                       (ex. gain, NF, S21, fréquences limites, etc.)
        """
        self.name = name
        self.params = params  # Stocke les caractéristiques du composant

    @abstractmethod
    def process(self, signals: Dict[float, float]) -> Dict[float, float]:
        """
        Méthode abstraite à implémenter dans chaque composant concret.
        Elle prend en entrée un dictionnaire {fréquence_MHz: puissance_dBm}
        et renvoie un dictionnaire {fréquence_MHz: puissance_dBm} apres
        application du comportement du composant.
        
        :param signals: dictionnaire des signaux en entrée
        :return: dictionnaire des signaux en sortie apres traitement
        """
        # Ici on leve une erreur si la sous-classe n'implémente pas cette méthode
        raise NotImplementedError("Must be implemented in subclass.")
