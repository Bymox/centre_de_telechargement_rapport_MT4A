# =============================================================================
# simulate_chain.py
# =============================================================================
# Script principal pour simuler une chaîne RF définie par :
#   - chain.yaml : ordre des composants
#   - components.yaml : caractéristiques de chaque composant
#   - config.yaml : paramètres de simulation (signaux, fréquences, variable filters…)
#
# Fonctionnalités :
#   - charge les configurations et composants
#   - applique chaque composant sur les signaux d'entrée
#   - calcule gain total, NF total et IP1dB d'entrée
#   - trace le spectre simulé avec annotations et markers
# =============================================================================

import yaml
import numpy as np
from utils.plot import plot_spectrum
from components.switch import Switch
from components.lna import LNA
from components.attenuator_fixed import AttenuatorFixed
from components.attenuator_variable import AttenuatorVariable
from components.variable_filter import VariableFilter
from components.mixer import Mixer
from components.filter import Filter
from components.preselector import Preselector
from components.bpf_500_filter import BPF500Filter
from components.HPF_4GHz import HPF_4GHz

from utils.calculator import build_chain, calc_nf, calc_ip1db, db2lin, lin2db

# Mapping type → classe Python correspondante
component_classes = {
    "lna": LNA,
    "switch": Switch,
    "attenuator_fixed": AttenuatorFixed,
    "attenuator_variable": AttenuatorVariable,
    "variable_filter": VariableFilter,
    "mixer": Mixer,
    "HPF4G": HPF_4GHz,
    "bpf_500_filter": BPF500Filter,
    "preselector": Preselector,
    "filter": Filter,
}

# -------------------------------
# Helper : lecture YAML
# -------------------------------
def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# =============================================================================
# Main simulation
# =============================================================================
def main():
    # 1) Charger les fichiers YAML
    cfg        = load_yaml("config/config.yaml")        # config simulation
    chain_cfg  = load_yaml("config/chain.yaml")        # ordre des composants
    comps_cfg  = load_yaml("config/components.yaml")   # caractéristiques composants

    # 2) Mettre à jour les filtres variables avec l'état courant
    var_f_over = cfg.get("variable_filters", {})
    for name in var_f_over:
        if name not in comps_cfg:
            comps_cfg[name] = {"type": "variable_filter"}

    # 3) Mixer : récupérer LO et mode (high/infradyne)
    mixer_ov = cfg.get("mixer", {})
    LO       = mixer_ov.get("lo_freq_MHz")
    MODE     = mixer_ov.get("mode", "high")

    # 4) Préparer les signaux d'entrée
    raw_ins = cfg["input_signals"]
    input_signals = {}
    input_labels  = {}
    for f_str, v in raw_ins.items():
        f = float(f_str)
        if isinstance(v, dict):
            input_signals[f] = float(v["power"])
            input_labels[f]  = v.get("label", "")
        else:
            input_signals[f] = float(v)
            input_labels[f]  = ""

    # 5) Paramètres de plot
    pfmin, pfmax = cfg["plot_freq_range_MHz"]
    pmin, pmax   = cfg["plot_power_range_dBm"]
    y_step       = cfg.get("plot_y_tick_step_dB", 10)
    x_step       = cfg.get("plot_x_tick_step_GHz", 0.1)
    min_p        = cfg.get("plot_min_power_dBm", -200)
    afmin, afmax = cfg.get("plot_annot_range_MHz", [pfmin, pfmax])
    acolor       = cfg.get("plot_annot_color", "#FF00FF")

    # -------------------------------
    # 6) Simulation des blocs
    # -------------------------------
    signals = input_signals.copy()
    for entry in chain_cfg["chain"]:
        name     = entry["name"]
        comp_cfg = comps_cfg[name]
        params   = {k: v for k, v in comp_cfg.items() if k != "type"}
        ctype    = comp_cfg["type"]

        # Override des paramètres du mixer
        if ctype == "mixer":
            params.update({k: v for k, v in mixer_ov.items() if v is not None})

        # Override pour filtre variable
        if ctype == "variable_filter" and name in var_f_over:
            params.update(var_f_over[name])

        # Instanciation du composant et traitement des signaux
        comp    = component_classes[ctype](name, params)
        signals = comp.process(signals)

    # -------------------------------
    # 7) Calcul des fréquences FI à partir du LO
    # -------------------------------
    rf_freqs = sorted(input_signals.keys())
    if LO is not None:
        if MODE == "low":
            fi_freqs = [abs(rf - LO) for rf in rf_freqs]
        else:
            fi_freqs = [abs(LO - rf) for rf in rf_freqs]
    else:
        fi_freqs = []

    # -------------------------------
    # 8) Création des markers pour le plot
    # -------------------------------
    markers = []
    tol = 1e-6
    for f, p in signals.items():
        lbl = ""
        # RF d'origine
        for rf, lab in input_labels.items():
            if abs(f - rf) < tol:
                lbl = lab
                break
        # Conversion via mixer
        if not lbl and LO is not None:
            for rf, lab in input_labels.items():
                target = abs((LO - rf) if MODE=="high" else (rf - LO))
                if abs(f - target) < tol:
                    lbl = lab
                    break
        color = 'red' if not any(abs(f - x) < tol for x in rf_freqs+fi_freqs) else None
        markers.append((f, p, color, lbl))

    # -------------------------------
    # 9) Calcul des performances RF
    # -------------------------------
    chain      = build_chain("config/components.yaml", "config/chain.yaml", "config/config.yaml")
    total_nf   = calc_nf(chain)
    ip1dB_in   = calc_ip1db(chain)
    total_gain = lin2db(float(np.prod([s["gain_lin"] for s in chain])))

    # -------------------------------
    # 10) Appel de la fonction de plot
    # -------------------------------
    freqs  = np.array(sorted(signals.keys()))
    powers = np.array([signals[f] for f in freqs])
    summary_freq_GHz = cfg["calculator_freq_MHz"] / 1000

    plot_spectrum(
        freqs, powers,
        markers=markers,
        fmin=pfmin, fmax=pfmax,
        ymin=pmin, ymax=pmax,
        ytick_step=y_step,
        xtick_step_GHz=x_step,
        min_power_dBm=min_p,
        annot_range_MHz=(afmin, afmax),
        annot_color=acolor,
        rf_freq_MHz=rf_freqs,
        fi_freq_MHz=fi_freqs,
        summary_freq_GHz=summary_freq_GHz,
        summary_gain_dB=total_gain,
        summary_nf_dB=total_nf,
        summary_ip1dB=ip1dB_in
    )

if __name__ == "__main__":
    main()
