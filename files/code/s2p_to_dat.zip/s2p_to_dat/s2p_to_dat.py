import os

def convert_s2p(s2p_path: str, output_dir: str):
    """
    Lit un fichier .s2p et génère dans output_dir :
      - <basename>_S11.dat : freq(Hz) et S11
      - <basename>_S21.dat : freq(Hz) et S21
    """
    if not os.path.isfile(s2p_path):
        raise FileNotFoundError(f"Fichier introuvable : {s2p_path}")

    os.makedirs(output_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(s2p_path))[0]
    s11_out = os.path.join(output_dir, f"{base}_S11.dat")
    s21_out = os.path.join(output_dir, f"{base}_S21.dat")

    with open(s2p_path, "r") as fin, \
         open(s11_out, "w") as f11, \
         open(s21_out, "w") as f21:

        # Header optionnel
        f11.write("# freq(Hz)\tS11\n")
        f21.write("# freq(Hz)\tS21\n")

        for line in fin:
            line = line.strip()
            # sauter commentaires et header
            if not line or line.startswith("#") or line.startswith("!"):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            freq, s11, s21 = parts[0], parts[1], parts[3]
            f11.write(f"{freq}\t{s11}\n")
            f21.write(f"{freq}\t{s21}\n")

    print(f"✅ Converti {s2p_path}")
    print(f"   → {s11_out}")
    print(f"   → {s21_out}")

if __name__ == "__main__":
    # === À personnaliser ===
    input_file  = r"C:\Users\a942666\OneDrive - ATOS\Bureau\HPF_4GHz\HPF4G.s2p"
    output_dir  = r"C:\Users\a942666\OneDrive - ATOS\Bureau\S21_HPF.dat"
    convert_s2p(input_file, output_dir)
